Integrantes: 

Álvaro Rull y Salvador Heras

Correos:

alvaro.rull@cunef.edu

salvador.heras@cunef.edu

Repositorios:

https://github.com/Alvaro-Rull/Bank-Fraud.git

https://github.com/salvaheras/Bank-Fraud.git